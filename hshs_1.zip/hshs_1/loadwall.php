<?php
	$servername = 'localhost';
    $username = 'root'; 
    $password = '12345678';
    $database = 'mt';
    $id = mysqli_connect( $servername, $username, $password, $database);
    if (!$id) {
        die("Connection failed: ".mysqli_connect_error()); 
    } 
	$sql = "Select * From comment";
	$result = mysqli_query($id,$sql);
    $dataarr = array();
	while($row = mysqli_fetch_array($result)){
		array_push($dataarr, $row);
	}
	mysqli_close($id);
	echo json_encode($dataarr);
?>