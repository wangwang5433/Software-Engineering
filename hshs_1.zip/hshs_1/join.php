<?php
    //The first question: empty_input
    //The second question: password_error
    //The third question: "The_Account_has_been_registered" 
    //The fourth question: The_Email_has_been_registered
    $servername = 'localhost';
    $username = 'root'; 
    $password = '12345678';
    $database = 'mt';
    $Registered_success="false";
    if(isset($_POST["UserID"])) {
        $UserID=$_POST["UserID"];
    }
    else{
		echo "no_UserID".",";
    } 
    if(isset($_POST["Password"])){
        $Password=$_POST["Password"];
    }
    else{
        echo "no_Password".",";
    }
    if(isset($_POST["Name"])){
        $Name= $_POST["Name"];
    }
    else{
        echo "no_Name".","; 
    }
    if(isset($_POST["Password2"])){
        $Password2=$_POST["Password2"];
    }else{
        echo "no_Password2".",";
    }
    if ( empty($UserID) || empty($Password) || empty($Name)) {
        echo "empty_input"."}";
        exit; 
    }else{
    echo "pass".",";
    }
    if ( $Password <> $Password2 ) {
    exit;
    }else{
    echo "pass".",";
    }
    $id = mysqli_connect( $servername, $username, $password, $database);
    if (!$id) {
        die("Connection failed: ".mysqli_connect_error()); 
    } 
    $sql = "Select * From id Where Userid='$UserID'";
    $rows = mysqli_query( $id, $sql);
    $num = mysqli_num_rows($rows);
    if ($num <> 0) {
        echo "<script language=\"JavaScript\">\r\n";
		echo " alert(\"已被註冊\");\r\n";
		echo " history.back();\r\n";
		echo "</script>";
        exit;
    }
    else{
        echo "pass".",";
    }
    $sql = "Insert Into `id` (`Userid`, `Password`) Values ('{$_POST['UserID']}','{$_POST['Password']}')";
    mysqli_query($id, $sql);
    $Registered_success="true";
    if($Registered_success)
    {
		header("Location:./login.html");
    }
    echo $Registered_success; 
	echo "}"; 
?>
        

