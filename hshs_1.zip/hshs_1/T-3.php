<?php
$hostname="localhost";
$username="root";
$password="ab9511320";				//
$database="final";				//

$link=mysqli_connect($hostname,$username,$password);
mysqli_query($link,"SET NAMES 'UTF8'");
mysqli_select_db($link,$database) or die ("無法選擇資料庫");

//墓園
$sql="select * from tomb,address where tomb.PostalCode=address.PostalCode";
$result=mysqli_query($link,$sql) or die ("無法送出".mysqli_error());
$T=mysqli_num_rows($result);
while($content=mysqli_fetch_assoc($result)){
	$Tomb['tombID'][]=$content['TombID'];
	$Tomb['name'][]=$content['CemteryName'];
	$Tomb['address'][]=$content['Country'] . $content['District'] . $content['Address'];
	if($content['part1tel']==null){
		$Tomb['tel'][]=$content['part2tel'];
	}else{
		$Tomb['tel'][]='('. $content['part1tel'] . ')' . $content['part2tel'];
	}
	$Tomb['x'][]=$content['Px'];
	$Tomb['y'][]=$content['Py'];
};
mysqli_free_result($result);

//花店
$sql="select Country,District,tomb.TombID,StoreName,shop.Part1tel,shop.Part2tel,shop.Address,shop.Px,shop.Py 
		from tomb,shop,address,relation,shopcategoory,srelation where shop.PostalCode=address.PostalCode
		and srelation.ShopID=shop.ShopID and srelation.type=shopcategoory.type and tomb.TombID=relation.TombID
		and relation.ShopID=shop.ShopID and shopcategoory.type='花店'";
$result=mysqli_query($link,$sql) or die ("無法送出".mysqli_error());
$F=mysqli_num_rows($result);
while($content=mysqli_fetch_assoc($result)){
	$Flower['tombID'][]=$content['TombID'];
	$Flower['name'][]=$content['StoreName'];
	$Flower['address'][]=$content['Country'] . $content['District'] . $content['Address'];
	if($content['Part1tel']==null){
		$Flower['tel'][]=$content['Part2tel'];
	}else{
		$Flower['tel'][]='('. $content['Part1tel'] . ')' . $content['Part2tel'];
	}
	$Flower['x'][]=$content['Px'];
	$Flower['y'][]=$content['Py'];
};
mysqli_free_result($result);

//金紙店
$sql="select Country,District,tomb.TombID,StoreName,shop.Part1tel,shop.Part2tel,shop.Address,shop.Px,shop.Py 
		from tomb,shop,address,relation,shopcategoory,srelation where shop.PostalCode=address.PostalCode
		and srelation.ShopID=shop.ShopID and srelation.type=shopcategoory.type and tomb.TombID=relation.TombID
		and relation.ShopID=shop.ShopID and shopcategoory.type='金紙店'";
$result=mysqli_query($link,$sql) or die ("無法送出".mysqli_error());
$M=mysqli_num_rows($result);
while($content=mysqli_fetch_assoc($result)){
	$Money['tombID'][]=$content['TombID'];
	$Money['name'][]=$content['StoreName'];
	$Money['address'][]=$content['Country'] . $content['District'] . $content['Address'];
	if($content['Part1tel']==null){
		$Money['tel'][]=$content['Part2tel'];
	}else{
		$Money['tel'][]='('. $content['Part1tel'] . ')' . $content['Part2tel'];
	}
	$Money['x'][]=$content['Px'];
	$Money['y'][]=$content['Py'];
};
mysqli_free_result($result);

//餐廳
$R=0;
for($i=1;$i<6;$i++){				//<--查詢1~5間墓地的餐廳  (一次查詢全部資料時過大)
	$tempx=$Tomb['x'][$i];
	$tempy=$Tomb['y'][$i];
	$sql="select StoreName,Part1tel,Part2tel,Address,Px,Py,Country,District,
			(acos(
				sin((" . $tempy . "*3.1415)/180) * sin((Py*3.1415)/180) + 
				cos((" . $tempy . "*3.1415)/180) * cos((Py*3.1415)/180) * cos((" . $tempx . "*3.1415)/180 - (Px*3.1415)/180)
				)*6370.996) as distance
			FROM shop,address,shopcategoory,srelation
			where shop.ShopID=srelation.ShopID and srelation.type=shopcategoory.type and address.PostalCode=shop.PostalCode and shopcategoory.type='美食'
			having distance <= 2.5 order by distance asc";
	$result=mysqli_query($link,$sql) or die ("無法送出".mysqli_error());
	$number=mysqli_num_rows($result);
	while($content=mysqli_fetch_assoc($result)){
		$Res['tombID'][$R]=$Tomb['tombID'][$i];
		$Res['name'][$R]=$content['StoreName'];
		$Res['address'][$R]=$content['Country'] . $content['District'] . $content['Address'];
		if($content['Part1tel']==null){
			$Res['tel'][$R]=$content['Part2tel'];
		}else{
			$Res['tel'][$R]='('. $content['Part1tel'] . ')' . $content['Part2tel'];
		}
		$Res['x'][$R]=$content['Px'];
		$Res['y'][$R]=$content['Py'];
		$R++;
	};
	mysqli_free_result($result);
}
?>

<html>
	<head>
		<meta charset="utf-8">
		<title>Test</title>
		<script>
			var TotalT= <?php echo $T ?>;				//墓園總共TotalT間
			var TotalF= <?php echo $F ?>;				//花店
			var TotalM= <?php echo $M ?>;				//金紙店
			var TotalR= <?php echo $R ?>;				//餐廳
			var Tomb=new Array(new Array());
			Tomb['tombID']= <?php echo json_encode($Tomb['tombID'])?>;
			Tomb['Tname']= <?php echo json_encode($Tomb['name'])?>;
			Tomb['address']= <?php echo json_encode($Tomb['address'])?>;
			Tomb['tel']= <?php echo json_encode($Tomb['tel'])?>;
			Tomb['x']= <?php echo json_encode($Tomb['x'])?>;
			Tomb['y']= <?php echo json_encode($Tomb['y'])?>;
			
			var Flower=new Array(new Array());
			Flower['tombID']= <?php echo json_encode($Flower['tombID'])?>;
			Flower['Fname']= <?php echo json_encode($Flower['name'])?>;
			Flower['address']= <?php echo json_encode($Flower['address'])?>;
			Flower['tel']= <?php echo json_encode($Flower['tel'])?>;
			Flower['x']= <?php echo json_encode($Flower['x'])?>;
			Flower['y']= <?php echo json_encode($Flower['y'])?>;
			
			var Money=new Array(new Array());
			Money['tombID']= <?php echo json_encode($Money['tombID'])?>;
			Money['Mname']= <?php echo json_encode($Money['name'])?>;
			Money['address']= <?php echo json_encode($Money['address'])?>;
			Money['tel']= <?php echo json_encode($Money['tel'])?>;
			Money['x']= <?php echo json_encode($Money['x'])?>;
			Money['y']= <?php echo json_encode($Money['y'])?>;
			
			var Res=new Array(new Array());
			Res['tombID']= <?php echo json_encode($Res['tombID'])?>;
			Res['Rname']= <?php echo json_encode($Res['name'])?>;
			Res['address']= <?php echo json_encode($Res['address'])?>;
			Res['tel']= <?php echo json_encode($Res['tel'])?>;
			Res['x']= <?php echo json_encode($Res['x'])?>;
			Res['y']= <?php echo json_encode($Res['y'])?>;
		</script>
	</head>
	<body>
		<script>
			var number=6;				//<--輸出number筆資料
			document.writeln("總共"+TotalT+"間墓地<br>")
			for(var i=1;i<number;i++){
				document.writeln("<h3>"+"墓地；&nbsp"+"&nbsp"+Tomb['Tname'][i]+"&nbsp ；"+Tomb['address'][i]+"&nbsp ；"+Tomb['x'][i]+"&nbsp ；"+Tomb['y'][i]+"&nbsp ；"+Tomb['tel'][i]+"&nbsp；"+Tomb['tombID'][i]+"</h3>");
				for(var j=0;j<TotalF;j++){
					if(Flower['tombID'][j]==Tomb['tombID'][i]){
						document.writeln("<p>花店； &nbsp"+Flower['Fname'][j]+"&nbsp；"+Flower['address'][j]+"&nbsp； "+Flower['x'][j]+"&nbsp； "+Flower['y'][j]+"&nbsp；"+Flower['tel'][j]+"</p>");
					}
				};
				for(var j=0;j<TotalM;j++){
					if(Money['tombID'][j]==Tomb['tombID'][i]){
						document.writeln("<p>金紙店； &nbsp"+Money['Mname'][j]+"&nbsp；"+Money['address'][j]+"&nbsp； "+Money['x'][j]+"&nbsp； "+Money['y'][j]+"&nbsp；"+Money['tel'][j]+"</p>");
					}
				};
				for(var j=0;j<TotalR;j++){
					if(Res['tombID'][j]==Tomb['tombID'][i]){
						document.writeln("<p>餐廳； &nbsp"+Res['Rname'][j]+"&nbsp；"+Res['address'][j]+"&nbsp； "+Res['x'][j]+"&nbsp ；"+Res['y'][j]+"&nbsp；"+Res['tel'][j]+"</p>");
					}
				};
				document.writeln('<br>');
			}
		</script>
	</body>
</html>