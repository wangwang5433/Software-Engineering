<?PHP
  header("Content-Type: text/html; charset=utf8");
//   if(!isset($_POST["submit"])){
//     exit("錯誤執行");
//   }//檢測是否有submit操作 
//   include('connect.php');//連結資料庫
  $account = $_POST["userid"];//post獲得使用者名稱錶單值
  $pass = $_POST["pass"];//post獲得使用者密碼單值
	if ($account=='' || $pass==''){
		echo "<script language=\"JavaScript\">\r\n";
		echo " alert(\"使用者名稱或密碼不能為空\");\r\n";
		echo " history.back();\r\n";
		echo "</script>";
		exit;
		// echo '<script language="JavaScript">;alert("使用者名稱和密碼不能為空";location:login.html";</script>;';
	
	}else{//如果使用者名稱和密碼都不為空
		$servername = 'localhost';
    	$username = 'root'; 
    	$password = '12345678';
    	$database = 'mt';
		$Registered_success="false";
		$id = mysqli_connect( $servername, $username, $password, $database);
       	$sql = "Select * From id Where `Userid` = '$account' and `Password` = '$pass'";//檢測資料庫是否有對應的username和password的sql
		   if(isset($sql)){
			$rows = mysqli_query( $id, $sql);
			$num = mysqli_num_rows($rows);
					
    		// if ($num <> 0) {
			// 	echo "pass|";
			// 	header('Location: '.$uri.'/mm.html');
        	// 	// exit;
			   // }
        	if($num <> 0){//0 false 1 true
				mysqli_free_result($rows);
				mysqli_close($id);
				setcookie("account",$account);
				setcookie("password",$password);
				header('Location:index.html');
				exit;
			}
			else{
				echo "<script language=\"JavaScript\">\r\n";
				echo " alert(\"輸入錯誤\");\r\n";
				echo " history.back();\r\n";
				echo "</script>";
				exit;
    	    //如果錯誤
    	   	}
		}
   	}  
 
?>