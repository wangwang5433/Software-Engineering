<?php
    //The first question: empty_input
    //The second question: password_error
    //The third question: "The_Account_has_been_registered" 
    //The fourth question: The_Email_has_been_registered
    $servername = 'localhost';
    $username = 'root'; 
    $password = '12345678';
    $database = 'mt';
    $Registered_success="false";
	$MovieID=$_POST['sele'];
    $cost=$_POST['coco'];
	$seat=$_POST['seat'];
	$Userid=$_COOKIE['account'];
	if ( empty($MovieID) ) {
        echo "empty_input"."}";
        exit; 
    }else{
		echo "pass".",";
    }
    $id = mysqli_connect( $servername, $username, $password, $database);
    if (!$id) {
        die("Connection failed: ".mysqli_connect_error()); 
    } 

	$TicketID='TS';
	$cksql ="";
	$TicketID= $TicketID.json_encode(rand(0,9)).json_encode(rand(0,9)).json_encode(rand(0,9)).json_encode(rand(0,9)).json_encode(rand(0,9));
	/*do
	{
		//roll
		$ArticleID='S';
		$ArticleID= $ArticleID.json_encode(rand(0,9)).json_encode(rand(0,9)).json_encode(rand(0,9)).json_encode(rand(0,9)).json_encode(rand(0,9));
		$cksql = "Select ArticleID From `comment` Where ArticleID =".json_encode($ArticleID);
		$row=mysqli_query( $id, $cksql);
		if(!$row)
			throw new Exception("not good sql");
		$isExist=mysqli_num_rows($row)>0;
	}
	while(!$isExist);*/

	
	
	
	/*
	while(1){
		$rows = mysqli_query( $id, $cksql);
		if(isset($rows)){
			$ArticleID = 'S';
			for ($i = 0; $i < 5; $i++) {
				$ArticleID .= rand(0,9);
			}
			continue;
		}else
		break;	
	}*/
	$sql = "INSERT INTO `ticket` (`TicketID`, `MovieID`, `cost`, `seat`, `Userid`) VALUES ('$TicketID', '$MovieID', '$cost', '$seat', '$Userid');";
    mysqli_query($id, $sql);
    header('Location:index.html');
?>
        

